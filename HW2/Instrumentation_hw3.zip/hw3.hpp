//
//  hw2.hpp
//  
//
//  Created by Siqi Liu on 2016-01-21.
//
//

#ifndef hw2_hpp
#define hw2_hpp

#include <stdio.h>
#include <cmath>
#include <iostream>
#include <rarray>
#include <rarrayio>
#include "initialize.hpp"
#include "output.hpp"
#include "singlestep.hpp"
#include "ticktock.h"

#endif /* hw2_hpp */
