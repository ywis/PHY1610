//
//  output.hpp
//  
//
//  Created by Siqi Liu on 2016-01-25.
//
//

#ifndef output_hpp
#define output_hpp

#include <stdio.h>
#include <iostream>
#include <rarray>
#include <rarrayio>

void output(const int n_ants,int t,float totants, rarray<float,2> number_of_ants);
#endif /* simulate_hpp */
